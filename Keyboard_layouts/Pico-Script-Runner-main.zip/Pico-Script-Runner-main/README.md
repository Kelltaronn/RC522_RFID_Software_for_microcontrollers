[![Youtube](https://img.shields.io/badge/YouTube-FF0000?style=flat-square&logo=youtube&logoColor=white)](https://www.youtube.com/channel/UCgF78i8PUYdKLgjpyeCJ7Qg)

Tech Notebook USB Rubber Ducky Projcet




This is a Raspberry Pi Script Runner. It emulates a keyboard in order to run commands. The code.py file allows you to extract network information from a computer.
