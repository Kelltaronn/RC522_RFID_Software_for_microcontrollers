import klavye

k = klavye.hidkeyboard()

data = "\"1234567890*-!'+%&/()=?_#${[]}\\,;.:@qwertyuıopğüasdfghjklşizxcvbnmöçQWERTYUIOPĞÜASDFGHJKLŞİZXCVBNMÖÇ"

k.write(data)