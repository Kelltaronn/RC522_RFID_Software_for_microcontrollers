"""
k.press(0x04) # a
k.press(0x05) # b
k.press(0x06) # c
k.press(0x07) # d
k.press(0x08) # e
k.press(0x09) # f
k.press(0x0a) # g
k.press(0x0b) # h
k.press(0x0c) # ı
k.press(0x0d) # j
k.press(0x0e) # k
k.press(0x0f) # l
k.press(0x10) # m
k.press(0x11) # n
k.press(0x12) # o
k.press(0x13) # p
k.press(0x14) # q
k.press(0x15) # r
k.press(0x16) # s
k.press(0x17) # t
k.press(0x18) # u
k.press(0x19) # v
k.press(0x1a) # w
k.press(0x1b) # x
k.press(0x1c) # y
k.press(0x1d) # z
k.press(0x2f) # ğ
k.press(0x30) # ü
k.press(0x34) # i
k.press(0x36) # ö
k.press(0x37) # ç
k.press(0x33) # ş

k.press(0x1e) # 1
k.press(0x1f) # 2
k.press(0x20) # 3
k.press(0x21) # 4
k.press(0x22) # 5
k.press(0x23) # 6
k.press(0x24) # 7
k.press(0x25) # 8
k.press(0x26) # 9
k.press(0x27) # 0


k.press(0x28) # Enter
k.press(0x29) # Escape
k.press(0x2a) # Backspace
k.press(0x2b) # Tab
k.press(0x2c) # Space
k.press(0x2d) # *
k.press(0x2e) # -
k.press(0x31) # ,
k.press(0x32) # ,
k.press(0x35) # "
k.press(0x38) # .
k.press(0x39) # CapsLock
k.release_all()

k.press(0x3a) # F1
k.press(0x3b) # F2
k.press(0x3c) # F3
k.press(0x3d) # F4
k.press(0x3e) # F5
k.press(0x3f) # F6
k.press(0x40) # F7
k.press(0x41) # F8
k.press(0x42) # F9
k.press(0x43) # F10
k.press(0x44) # F11
k.press(0x45) # F12
k.press(0x68) # F13
k.press(0x69) # F14
k.press(0x6a) # F15
k.press(0x6b) # F16
k.press(0x6c) # F17
k.press(0x6d) # F18
k.press(0x6e) # F19
k.press(0x6f) # F20
k.press(0x70) # F21
k.press(0x71) # F22
k.press(0x72) # F23
k.press(0x73) # F24
k.press(0x74) # F25
k.press(0x75) # F26


k.press(0x46) # PrintScreen
k.press(0x47) # PageDown
k.press(0x48) # Pause
k.press(0x49) # Insert
k.press(0x4a) # Home
k.press(0x4b) # PageUp
k.press(0x4c) # Delete
k.press(0x4d) # End
k.press(0x4e) # Next
k.press(0x4f) # Right Arrow
k.press(0x50) # Left Arrow
k.press(0x51) # Down Arrow
k.press(0x52) # Up Arrow
k.press(0x53) # NumLock
k.press(0x54) # / (keypad side)
k.press(0x55) # * (keypad side)
k.press(0x56) # - (keypad side)
k.press(0x57) # + (keypad side)
k.press(0x58) # Enter (keypad side)
k.press(0x59) # 1 (keypad side)
k.press(0x5a) # 2 (keypad side)
k.press(0x5b) # 3 (keypad side)
k.press(0x5c) # 4 (keypad side)
k.press(0x5d) # 5 (keypad side)
k.press(0x5e) # 6 (keypad side)
k.press(0x5f) # 7 (keypad side)
k.press(0x60) # 8 (keypad side)
k.press(0x61) # 9 (keypad side)
k.press(0x62) # 0 (keypad side)
k.press(0x63) # , (keypad side)

k.press(0x64) # <
k.press(0x65) # Apps
k.press(0x66) # OemClear
k.press(0x67) # Clear
"""